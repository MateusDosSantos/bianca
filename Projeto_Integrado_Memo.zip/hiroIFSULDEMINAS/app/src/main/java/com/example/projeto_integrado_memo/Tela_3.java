package com.example.projeto_integrado_memo;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;

public class Tela_3 extends AppCompatActivity implements View.OnClickListener, Runnable{

    private TextView Nome;

    private Button Again, The_End;

    private ImageView IMG, Img, img, iMG, Img1, Img2;

    private ImageView DLCIMG, DLCImg, DLCimg, DLCiMG;

    private int ImageImg1, ImageImg2, CountTouch, counting;

    private Handler handler;

    private ArrayList<Integer> list;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela3);

        Img = findViewById(R.id.imageView002);
        IMG = findViewById(R.id.imageView004);
        img = findViewById(R.id.imageView008);
        iMG = findViewById(R.id.imageView006);
        DLCImg = findViewById(R.id.imageView007);
        DLCIMG = findViewById(R.id.imageView001);
        DLCimg = findViewById(R.id.imageView003);
        DLCiMG = findViewById(R.id.imageView005);

        Again = findViewById(R.id.button3);
        The_End = findViewById(R.id.button4);
        counting = 1;

        list = new ArrayList<Integer>();
        list.add(R.drawable.ic_action_name_smile);

        Nome = findViewById(R.id.textView3);
        Intent In = getIntent();
        if (In != null) {
            Bundle Caixa = new Bundle();
            Caixa = In.getExtras();
            if (Caixa != null) {
                Nome.setText(Caixa.getString("nome"));
            }
        }

        Img = findViewById(R.id.imageView002);
        IMG = findViewById(R.id.imageView004);
        img = findViewById(R.id.imageView008);
        iMG = findViewById(R.id.imageView006);
        DLCImg = findViewById(R.id.imageView007);
        DLCIMG = findViewById(R.id.imageView001);
        DLCimg = findViewById(R.id.imageView003);
        DLCiMG = findViewById(R.id.imageView005);

        IMG.setOnClickListener(this);
        Img.setOnClickListener(this);
        img.setOnClickListener(this);
        iMG.setOnClickListener(this);
        DLCIMG.setOnClickListener(this);
        DLCImg.setOnClickListener(this);
        DLCimg.setOnClickListener(this);
        DLCiMG.setOnClickListener(this);

        Again.setOnClickListener(this);
        The_End.setOnClickListener(this);

        list = new ArrayList<Integer>();
        list.add(R.drawable.ic_action_name_smile);
        list.add(R.drawable.ic_action_name_smile);
        list.add(R.drawable.ic_action_name_flag);
        list.add(R.drawable.ic_action_name_flag);
        list.add(R.drawable.ic_action_name_kare);
        list.add(R.drawable.ic_action_name_kare);
        list.add(R.drawable.ic_action_name_music);
        list.add(R.drawable.ic_action_name_music);

        handler = new Handler();

        Img1 = new ImageView(this);
        Img2 = new ImageView(this);

        Reload();

    }

    public void Reload(){

        Collections.shuffle(list);
        IMG.setImageResource(list.get(0));
        Img.setImageResource(list.get(1));
        img.setImageResource(list.get(2));
        iMG.setImageResource(list.get(3));
        DLCIMG.setImageResource(list.get(4));
        DLCImg.setImageResource(list.get(5));
        DLCimg.setImageResource(list.get(6));
        DLCiMG.setImageResource(list.get(7));

        handler.postDelayed(this, 3000);

        CountTouch = 0;

        IMG.setBackgroundColor(Color.TRANSPARENT);
        Img.setBackgroundColor(Color.TRANSPARENT);
        img.setBackgroundColor(Color.TRANSPARENT);
        iMG.setBackgroundColor(Color.TRANSPARENT);
        DLCIMG.setBackgroundColor(Color.TRANSPARENT);
        DLCImg.setBackgroundColor(Color.TRANSPARENT);
        DLCimg.setBackgroundColor(Color.TRANSPARENT);
        DLCiMG.setBackgroundColor(Color.TRANSPARENT);

        img.setEnabled(true);
        Img.setEnabled(true);
        IMG.setEnabled(true);
        iMG.setEnabled(true);
        DLCimg.setEnabled(true);
        DLCImg.setEnabled(true);
        DLCIMG.setEnabled(true);
        DLCiMG.setEnabled(true);
    }

    public void compare(int Image1, int Image2){

        CountTouch = 0;

        if(Image1 == Image2){

            Img1.setBackgroundColor(Color.GREEN);
            Img2.setBackgroundColor(Color.GREEN);
            Img1.setEnabled(false);
            Img1.setEnabled(false);

        }else{

            Img1.setBackgroundColor(Color.RED);
            Img2.setBackgroundColor(Color.RED);
            Handler Hand = new Handler();
            Hand.postDelayed(new Runnable() {

                @Override
                public void run() {

                    Img1.setBackgroundColor(Color.TRANSPARENT);
                    Img2.setBackgroundColor(Color.TRANSPARENT);
                    Img1.setImageResource(R.drawable.ic_action_name_gamble);
                    Img2.setImageResource(R.drawable.ic_action_name_gamble);
                }

            }, 2000);

        }
    }

    @Override
    public void onClick(View view) {

        CountTouch++;

        if(view == IMG){
            IMG.setImageResource(list.get(0));

            if(CountTouch == 1){

                Img1 = IMG;
                ImageImg1 = list.get(0);

            }else{

                Img2 = IMG;
                ImageImg2 = list.get(0);
                compare(ImageImg1,ImageImg2);

            }

        }
        if(view == Img){
            Img.setImageResource(list.get(1));

            if(CountTouch == 1){

                Img1 = Img;
                ImageImg1 = list.get(1);

            }else{

                Img2 = Img;
                ImageImg2 = list.get(1);
                compare(ImageImg1,ImageImg2);

            }

        }
        if(view == img){
            img.setImageResource(list.get(2));

            if(CountTouch == 1){

                Img1 = img;
                ImageImg1 = list.get(2);

            }else{

                Img2 = img;
                ImageImg2 = list.get(2);
                compare(ImageImg1,ImageImg2);

            }

        }
        if(view == iMG){
            iMG.setImageResource(list.get(3));

            if(CountTouch == 1){

                Img1 = iMG;
                ImageImg1 = list.get(3);

            }else{

                Img2 = iMG;
                ImageImg2 = list.get(3);
                compare(ImageImg1,ImageImg2);

            }

        }

        if(view == DLCIMG){
            DLCIMG.setImageResource(list.get(4));

            if(CountTouch == 1){

                Img1 = DLCIMG;
                ImageImg1 = list.get(4);

            }else{
                Img2 = DLCIMG;
                ImageImg2 = list.get(4);
                compare(ImageImg1,ImageImg2);

            }

        }
        if(view == DLCImg){
            DLCImg.setImageResource(list.get(5));

            if(CountTouch == 1){

                Img1 = DLCImg;
                ImageImg1 = list.get(5);

            }else{

                Img2 = DLCImg;
                ImageImg2 = list.get(5);
                compare(ImageImg1,ImageImg2);

            }

        }
        if(view == DLCimg){
            DLCimg.setImageResource(list.get(6));

            if(CountTouch == 1){

                Img1 = DLCimg;
                ImageImg1 = list.get(6);
            }else{

                Img2 = DLCimg;
                ImageImg2 = list.get(6);
                compare(ImageImg1,ImageImg2);

            }

        }
        if(view == DLCiMG){
            DLCiMG.setImageResource(list.get(7));

            if(CountTouch == 1){

                Img1 = DLCiMG;
                ImageImg1 = list.get(7);

            }else{

                Img2 = DLCiMG;
                ImageImg2 = list.get(7);
                compare(ImageImg1,ImageImg2);

            }

        }

        if(view == Again){
            counting++;
            Reload();
        }

        if(view == The_End){

            Intent I = new Intent(this, DLC_Tela4Activity.class);
            Bundle Boxing = new Bundle();
            Boxing.putString("name", Nome.getText().toString());
            Boxing.putInt("counter", counting);
            I.putExtras(Boxing);
            startActivity(I);

           // startActivity(new Intent(this,DLC_Tela4Activity.class));
        }
    }

    @Override
    public void run() {
        IMG.setImageResource(R.drawable.ic_action_name_circle);
        Img.setImageResource(R.drawable.ic_action_name_circle);
        img.setImageResource(R.drawable.ic_action_name_circle);
        iMG.setImageResource(R.drawable.ic_action_name_circle);
        DLCIMG.setImageResource(R.drawable.ic_action_name_circle);
        DLCImg.setImageResource(R.drawable.ic_action_name_circle);
        DLCimg.setImageResource(R.drawable.ic_action_name_circle);
        DLCiMG.setImageResource(R.drawable.ic_action_name_circle);

    }


}