package com.example.projeto_integrado_memo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Tela_02 extends AppCompatActivity implements View.OnClickListener{

    private Button BTN;

    private EditText nome;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela02);

        nome = findViewById(R.id.editTextText);

        BTN = findViewById(R.id.button2);
        BTN.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        if(v == BTN){

            Intent I = new Intent(this, Tela_3.class);
            Bundle Box = new Bundle();
            Box.putString("nome", nome.getText().toString());
            I.putExtras(Box);
            startActivity(I);

        }

    }
}