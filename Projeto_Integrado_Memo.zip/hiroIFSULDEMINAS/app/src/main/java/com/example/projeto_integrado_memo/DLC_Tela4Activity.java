package com.example.projeto_integrado_memo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DLC_Tela4Activity extends AppCompatActivity {

    private TextView Name, conta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dlc_activity_main4);

        Name = findViewById(R.id.textView6);
        Intent In = getIntent();
        if (In != null) {
            Bundle Caixas = new Bundle();
            Caixas = In.getExtras();
            if (Caixas != null) {
                Name.setText("O nome do jogador é: "+Caixas.getString("name"));
            }
        }

        conta = findViewById(R.id.textView5);
        if (In != null) {
            Bundle Caixas = new Bundle();
            Caixas = In.getExtras();
            if (Caixas != null) {
                conta.setText("que jogou "+Integer.toString(Caixas.getInt("counter"))+" vezes.");
            }
        }


    }
}